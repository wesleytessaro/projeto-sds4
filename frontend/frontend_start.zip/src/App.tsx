function App() {
  return (
    <div>
      <h1 className="text-primary">Oláaaa Mundo!</h1>
    </div>
  );
}

export default App;
